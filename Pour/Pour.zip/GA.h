#pragma once
#include<vector>
#include <iostream>
#include <random>
using namespace std;
constexpr auto POPULATION_SIZE = 50;
constexpr auto N_GENERATIONS = 10;
constexpr auto DNA_SIZE = 3;
constexpr auto FEATURE_NUM = 500;

typedef vector<bool> DNA;
typedef vector<DNA> CHROME;
typedef vector<CHROME> POPULATION;

constexpr int SERIE_LENGTH = FEATURE_NUM;
constexpr float TransitionOperationResolution = 0.03; // 3mm /20ms
constexpr float RotationOperationResolution = 0.1; //~0.57 deg
class Operation {
public:
	float x = 0;
	float y = 0;
	float a = 0;
	Operation() {};
	Operation(DNA dna) {
		x = 0;
		y = 0;
		a = 0;
		if (dna[0]) {
			if (dna[1]) {
				if (!dna[2]) {
					a = -1;
				}
			}
			else {
				if (dna[2]) {
					y = -1;
				}
				else {
					x = 1;
				}
			}
		}
		else {
			if (dna[1]) {
				if (dna[2]) {
					x = -1;
				}
				else {
					y = 1;
				}
			}
			else {
				if (dna[2]) {
					a = 1;
				}
			}
		}
	}
	Operation(float _x, float _y, float _a) :x(_x), y(_y), a(_a) {};
};
typedef std::vector<Operation> OPERATION_SERIE;

#define readDataPath  "best_T.txt"

inline bool with_poss(float p) {
	return rand()%1000 < p * (float)1000;
}

class GA {
	/*unsigned int DNA_SIZE = 24;
	unsigned int FEATURE_NUM = 7;
	unsigned int POP_SIZE = 200;
	unsigned int N_GENERATIONS;*/
	float CROSSOVER_RATE;// = 0.9;
	float MUTATION_RATE;// = 0.003;
	POPULATION popular;

public:
	vector<float> fitness;
	GA(float c = 0.9, float m = 0.002) :CROSSOVER_RATE(c), MUTATION_RATE(m) {
		popular.clear();
		popular.reserve(POPULATION_SIZE);
		
		//Bonus!
		CHROME chrome = CHROME(FEATURE_NUM);
		FILE* fp = fopen(readDataPath, "r"); //���ļ�  
		if (fp == NULL)
		{
			printf("�ļ���ȡ����...");
			chrome = rand_chrome();
		}
		else {
			for (int i = 0; i < FEATURE_NUM; i++)
			{
				float temp[3];
				for (int j = 0; j < 3; j++)
				{
					fscanf(fp, "%f", &temp[j]);/*ÿ�ζ�ȡһ������fscanf���������ո���߻��н���*/
				}
				fscanf(fp, "\n");
				DNA dna(DNA_SIZE, false);
				if (temp[0] == 1) {
					dna[0] = true;
				}
				else if (temp[0] == -1) {
					dna[1] = true;
					dna[2] = true;
				}
				else {
					if (temp[1] == 1) {
						dna[1] = true;
					}
					else if (temp[1] == -1) {
						dna[0] = true;
						dna[2] = true;
					}
					else {
						if (temp[2] == 1) dna[2] = true;
						else if(temp[2]==-1) {
							dna[0] = true;
							dna[1] = true;
						}
					}
				}
				chrome[i] = dna;
			}
			fclose(fp);
		}
		popular.push_back(chrome);

		//POPULATION popu(POPULATION_SIZE);
		for (int k = 1; k < POPULATION_SIZE; k++) {
			CHROME chrome = rand_chrome();
			popular.push_back(chrome);
		}
	}
	inline static OPERATION_SERIE translateChrome(CHROME chrome) {
		OPERATION_SERIE iops(SERIE_LENGTH);
		for (int i = 0; i < SERIE_LENGTH; i++) {
			iops[i] = Operation(chrome[i]);
		}
		return iops;
	}
	inline static CHROME rand_chrome() {
		//default_random_engine e;
		std::random_device rd;
		std::mt19937 gen(rd());
		bernoulli_distribution u;
		CHROME chrome(FEATURE_NUM);
		for (int j = 0; j < FEATURE_NUM; j++) {
			DNA dna(DNA_SIZE);
			for (int i = 0; i < DNA_SIZE; i++) {
				dna[i] = u(gen);
			}
			chrome[j] = dna;
		}
		return chrome;
	}
	double maxValue() {
		return pow(2, DNA_SIZE);
	}
	float translate(DNA dna) {
		int ret = 0;
		int mass = 1;
		for (int i = 0; i < dna.size(); i++) {
			ret += mass * dna[i];
			mass *= 2;
		}
		return ret;
	}

	void evolve() {
		POPULATION new_pop(POPULATION_SIZE);
		for (int i = 0; i < POPULATION_SIZE; i++) {
			CHROME c = popular[i];
			// Cross
			if (with_poss(CROSSOVER_RATE)) {
				int p2i = rand() % POPULATION_SIZE;
				CHROME p2 = popular[p2i];
				int cross_dna = rand() % FEATURE_NUM;
				/*int cross_point = rand() % DNA_SIZE;
				for (int k = cross_point; k < DNA_SIZE; k++) {
					c[cross_dna][k] = p2[cross_dna][k];
				}*/
				for (int k = cross_dna + 1; k < FEATURE_NUM; k++) {
					c[k] = p2[k];
				}
			}
			// Mutation
			for (int j = 0; j < FEATURE_NUM; j++) {
				if (with_poss(MUTATION_RATE)) {
					//int mutate_dna = rand() % FEATURE_NUM;
					int mutate_point = rand() % DNA_SIZE;
					c[j][mutate_point] = !c[j][mutate_point];
				}
			}
			new_pop[i] = c;
		}
		popular.swap(new_pop);
	}
	POPULATION get_popu() {
		return popular;
	}
	void set_fitness(vector<float>* f) {
		this->fitness = *f;//assign(f.begin(), f.end());;
	}
	vector<int>* _select_with_possibility() {
		vector<int>* indexs = new vector<int>(POPULATION_SIZE);
		vector<float> values(POPULATION_SIZE);
		float value = 0;
		for (int i = 0; i < POPULATION_SIZE; i++) {
			value += fitness[i];
			values[i] = value;
		}
		for (int j = 0; j < POPULATION_SIZE; j++) {
			int p_ind = rand() % (int)ceil(value);
			for (int i = 0; i < POPULATION_SIZE; i++) {
				if (values[i] > p_ind) {
					(*indexs)[j] = i;
					break;
				}
			}
		}
		return indexs;
	}
	void select() {
		POPULATION new_pop(POPULATION_SIZE);
		vector<int>* inds = _select_with_possibility();
		for (int i = 0; i < POPULATION_SIZE; i++) {
			new_pop[i] = popular[(*inds)[i]];
		}
		popular.swap(new_pop);
	}

	int best_chrome_i() {
		float v = 0;
		int ret_i = 0;
		for (int i = 0; i < POPULATION_SIZE; i++) {
			if (fitness[i] > v) {
				v = fitness[i];
				ret_i = i;
			}
		}
		return ret_i;
	}
};
/*
* # GA
class GA():

	def select(self): # select good fitness, with replication
		fitness = self.get_fitness()
		idx = np.random.choice(np.arange(self.POP_SIZE), size=self.POP_SIZE, replace=True,
						   p=(fitness)/(fitness.sum()) )
		self.pop = self.pop[idx]
		#print('select',self.pop)

	def evolve(self):
		new_pop = []
		for p in self.pop: # parent
			child = p
			# cross
			if np.random.rand() < self.CROSSOVER_RATE:
				p2 = self.pop[np.random.randint(self.POP_SIZE)]
				cross_point = np.random.randint(0, self.DNA_SIZE*2)
				child[cross_point:] = p2[cross_point:]
			# mutation
			if np.random.rand() < self.MUTATION_RATE:
				mutate_point = np.random.randint(0, self.DNA_SIZE*2)
				child[mutate_point] ^= 1
			new_pop.append(child)
		self.pop = np.array(new_pop)


	def solve(self):
		for i in range(self.N_GENERATIONS):
			self.a = self.translateDNA()
			self.evolve()
			self.select()

	def get_fitness(self):
		a = self.translateDNA()
		pred = self.F(a)
		return -(pred - np.max(pred)) + 1e-3 # avoid negtive value

	def translateDNA(self):
		x_pop = self.pop[:,1::2]#�����б�ʾX
		y_pop = self.pop[:,::2] #ż���б�ʾy

		#pop:(POP_SIZE,DNA_SIZE)*(DNA_SIZE,1) --> (POP_SIZE,1)
		x = x_pop.dot(2**np.arange(self.DNA_SIZE)[::-1])/\
						float(2**self.DNA_SIZE-1)*(lim[1][0]-lim[0][0])+lim[0][0]
		y = y_pop.dot(2**np.arange(self.DNA_SIZE)[::-1])/\
						float(2**self.DNA_SIZE-1)*(lim[1][1]-lim[0][1])+lim[0][1]
		return [x,y]


	def print_info(self):
		fitness = self.get_fitness()
		min_fitness_index = np.argmin(fitness)
		print("min_fitness:", fitness[min_fitness_index])
		[x,y] = self.translateDNA()
		print("���ŵĻ����ͣ�", self.pop[min_fitness_index])
		print("(x, y):", (x[min_fitness_index], y[min_fitness_index]))
		print("��Сֵ��", self.F([x[min_fitness_index], y[min_fitness_index]]))

		#print_info(pop)
		plt.ioff()
		#plot_3d(ax)
		# Ŀ�꺯���仯����
		y1=self.F([x,y])
		y2=self.get_fitness()
		x0=list(range(len(y1)))
		plt.plot(x0,y1)
		plt.show()
		plt.plot(x0,y2)
		plt.show()
		drawResult(af,[x[min_fitness_index], y[min_fitness_index]])

*/