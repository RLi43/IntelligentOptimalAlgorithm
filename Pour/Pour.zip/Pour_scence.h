#pragma once
/*
* Copyright (c) 2013 Google, Inc.
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:
* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.
* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.
* 3. This notice may not be removed or altered from any source distribution.
*/
#include "Framework/Test.h"
#include "Framework/Main.h"
#include <iostream>
#include <vector>

#include "GA.h"

class PourScence;
typedef PourScence* PourSCreateFcn();

struct PourEntry
{
	const char* name;
	PourSCreateFcn* createFcn;
};

extern PourEntry pour_scence;

class PourScence : public Test
{
public:

	PourScence(OPERATION_SERIE _ops)
	{
		operations = _ops;

		b2Body* ground = NULL;
		{
			b2BodyDef bd;
			ground = m_world->CreateBody(&bd);
		}

		{
			b2EdgeShape shape_Edge;
			//ground
			b2FixtureDef fd; 
			fd.shape = &shape_Edge;
			fd.density = 0.0f;
			fd.friction = 0.6f;
			shape_Edge.Set(b2Vec2(-3.0f, -1.0f), b2Vec2(-2.0f, -1.0f));
			ground->CreateFixture(&fd);

			b2BodyDef bd;
			bd.type = b2_staticBody;
			bd.allowSleep = false;
			bd.position.Set(0.0f, 1.0f);
			b2PolygonShape shape;
			//dest cup
			b2Body* dest_body = m_world->CreateBody(&bd);
			shape.SetAsBox(0.05f, 2.0f, b2Vec2(-3.0f, 0.0f), 0.0);
			dest_body->CreateFixture(&shape, 5.0f);
			shape.SetAsBox(0.05f, 2.0f, b2Vec2(-2.0f, 0.0f), 0.0);
			dest_body->CreateFixture(&shape, 5.0f);
			shape.SetAsBox(0.5f, 0.05f, b2Vec2(-2.5f, -2.0f), 0.0);
			dest_body->CreateFixture(&shape, 5.0f);

			ctrl_pos = b2Vec2(1.0f, 8.0f);
			bd.position.Set(1.0f, 8.0f);
			bd.type = b2_dynamicBody;
			// source cup
			b2Body*  src_body = m_world->CreateBody(&bd);
			shape.SetAsBox(0.1f, 2.0f, b2Vec2(1.0f, 1.0f), 0.0);
			src_body->CreateFixture(&shape, 0.05f);
			shape.SetAsBox(0.1f, 2.0f, b2Vec2(-1.0f, 1.0f), 0.0);
			src_body->CreateFixture(&shape, 0.05f);
			//shape.SetAsBox(1.0f, 0.05f, b2Vec2(0.0f, 2.0f), 0.0);
			//body->CreateFixture(&shape, 5.0f);
			shape.SetAsBox(1.0f, 0.1f, b2Vec2(0.0f, -1.0f), 0.0);
			src_body->CreateFixture(&shape, 0.05f);

			b2BodyDef cpd;
			cpd.type = b2_staticBody;
			//cpd.position = ctrl_pos;
			//cpd.position.Set(1.0f, 3.0f); 
			//shape.SetAsBox(0.05f, 0.05f, b2Vec2(0, 0), 0.0);
			control_body = m_world->CreateBody(&cpd);
			//control_body->CreateFixture(&shape, 1.0f);
			control_body->SetTransform(ctrl_pos, 0);

			b2RevoluteJointDef rjd;
			rjd.bodyA = src_body;
			rjd.bodyB = control_body;
			rjd.localAnchorB = b2Vec2(0, 0);
			//rjd.Initialize(src_body, control_body, b2Vec2(0.0f, 0.0f));
			rjd.referenceAngle = 0.0f;
			rjd.motorSpeed = 0;
			rjd.maxMotorTorque = 50.0f;
			rjd.enableMotor = true;
			rjd.enableLimit = true;
			rjd.upperAngle = 0;
			rjd.lowerAngle = -3;
			m_joint = (b2RevoluteJoint*)m_world->CreateJoint(&rjd);


		}

		m_particleSystem->SetRadius(0.025f);
		const uint32 particleType = Pour_Main::GetParticleParameterValue();
		m_particleSystem->SetDamping(0.1f);

		{
			b2ParticleGroupDef pd;
			pd.flags = particleType;

			b2PolygonShape shape;
			shape.SetAsBox(0.9f, 0.6f, b2Vec2(1.0f, 7.8f), 0.0);

			pd.shape = &shape;
			b2ParticleGroup* const group = m_particleSystem->CreateParticleGroup(pd);
			if (pd.flags & b2_colorMixingParticle)
			{
				ColorParticleGroup(group, 0);
			}
		}
		m_time = 0;
		p_sum = m_particleSystem->GetParticleCount();
	}

	void Step(Settings* settings)
	{
		if (operation_iter < SERIE_LENGTH) {
			Operation oper = operations[operation_iter];
			//m_debugDraw.DrawString(5, m_textLine, "x/y/a = %.1f/%.1f/%.1f", oper.x, oper.y, oper.a);
			//m_textLine += DRAW_STRING_NEW_LINE;
			ctrl_angle_speed += RotationOperationResolution * oper.a;
			m_joint->SetMotorSpeed(ctrl_angle_speed);
			
			if (!settings->pause || settings->singleStep) {
				//printf("x/y/a = %.1f/%.1f/%.1f", oper.x, oper.y, oper.a);
				b2Vec2 cur_pos = control_body->GetPosition();
				b2Vec2 newpos = b2Vec2(cur_pos(0) + oper.x * TransitionOperationResolution,
					cur_pos(1) + oper.x * TransitionOperationResolution);
				control_body->SetTransform(newpos, 0);
				//printf("After: curPos: %f,%f", cur_pos(0), cur_pos(1));
				operation_iter++;
			}
		}
		else {
			m_joint->SetMotorSpeed(0);
		}
		Test::Step(settings);
		get_in_dest();
	}

	int32 get_in_dest() {
		int32 in_the_dest = 0;
		//int32 p_num = m_particleSystem->GetParticleCount();
		b2Vec2* ps_pos = m_particleSystem->GetPositionBuffer();
		b2Vec2 pos;
		for (int32 i = 0; i < p_sum; i++) {
			pos = ps_pos[i];
			if (pos(1) > -1&& pos(1) < 3 && pos(0) > -3.0 && pos(0) < -2.0) {
				in_the_dest++;
			}
		}
		//m_debugDraw.DrawString(5, m_textLine, "sum/in = %d/%d", p_num, in_the_dest);
		//m_textLine += DRAW_STRING_NEW_LINE;
		return in_the_dest;
	}

	float32 GetDefaultViewZoom() const
	{
		return 0.1f;
	}

	static PourScence* Create()
	{
		/*CHROME newChrome = GA::rand_chrome();
		OPERATION_SERIE iops(SERIE_LENGTH);
		for (int i = 0; i < SERIE_LENGTH; i++) {
			iops[i]=Operation(newChrome[i]);
		}*/

		FILE* fp = fopen(readDataPath, "r"); //���ļ�  
		if (fp == NULL)
		{
			printf("�ļ���ȡ����...");
			return nullptr;
		}
		OPERATION_SERIE ops = OPERATION_SERIE(FEATURE_NUM);
		for (int i = 0; i < FEATURE_NUM; i++)
		{
			float temp[3];
			for (int j = 0; j < 3; j++)
			{
				fscanf(fp, "%f", &temp[j]);/*ÿ�ζ�ȡһ������fscanf���������ո���߻��н���*/
			}
			fscanf(fp, "\n");
			Operation op(temp[0], temp[1], temp[2]);
			ops[i] = op;
		}
		fclose(fp);

		return new PourScence(ops);
	}
	int p_sum;
	b2Vec2 ctrl_pos;
	float ctrl_angle_speed;
	b2Body* control_body;
	b2RevoluteJoint* m_joint;
	float32 m_time;
	OPERATION_SERIE operations;
	int operation_iter = 0;
};

